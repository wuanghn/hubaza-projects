<?php

class Member extends \Eloquent 
{
	protected $table="members";
	protected $guarded = array();	
}