<?php

class Member extends \Eloquent {
	protected $fillable = [];
}