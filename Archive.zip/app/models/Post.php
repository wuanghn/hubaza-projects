<?php

class Post extends \Eloquent {
	//protected $fillable = [];
	protected $table = "posts";
	protected $guarded = array();

}